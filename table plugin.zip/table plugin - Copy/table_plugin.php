<?php
/*
 * Plugin Name: Excel Table Display
 * Description: Upload and display Excel files as tables on your website.
 * Version: 1.0
 * Author: Nikshep
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Load Composer's autoloader if it exists
$autoload = __DIR__ . '/vendor/autoload.php';
if (file_exists($autoload)) {
    require_once $autoload;
}

use PhpOffice\PhpSpreadsheet\Reader\Xlsx;

class Excel_Table_Display
{

    public function __construct()
    {
        // Add submenu page in admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));

        // Handle form submission in admin
        add_action('admin_post_process_excel_upload', array($this, 'handle_excel_upload'));

        // Add shortcode to display the uploaded Excel table
        add_shortcode('display_uploaded_excel_table', array($this, 'display_uploaded_excel_table'));
    }

    // Add submenu page in admin menu
    public function add_admin_menu()
    {
        add_menu_page(
            'Excel Table Display',
            'Excel Table Display',
            'manage_options',
            'excel-table-display',
            array($this, 'admin_page_content')
        );
    }

    // Admin page content
    public function admin_page_content()
    {
?>
        <div class="wrap">
            <h1>Excel Table Display</h1>
            <form method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="process_excel_upload">
                <?php wp_nonce_field('excel_table_upload_nonce', '_wpnonce'); ?>
                <label for="excel_file"><?php esc_html_e('Upload Excel File:', 'excel-table-display'); ?></label>
                <input type="file" name="excel_file" id="excel_file" accept=".xls,.xlsx">
                <input type="submit" name="submit_excel" value="<?php esc_attr_e('Upload', 'excel-table-display'); ?>">
            </form>
        </div>
<?php
    }

    // Handle form submission in admin
    public function handle_excel_upload()
    {
        // Security checks
        if (!current_user_can('upload_files') || !wp_verify_nonce($_POST['_wpnonce'], 'excel_table_upload_nonce')) {
            wp_die('Permission error');
        }

        // Check if file was uploaded without errors
        if ($_FILES['excel_file']['error'] === UPLOAD_ERR_OK) {
            $file_path = $_FILES['excel_file']['tmp_name'];

            // Process the uploaded Excel file
            $table_html = $this->process_excel_file($file_path);

            // Save table HTML in option for later retrieval
            update_option('excel_table_display_data', $table_html);

            // Redirect back to admin page with success message
            wp_redirect(admin_url('admin.php?page=excel-table-display&success=1'));
            exit;
        } else {
            // Handle upload errors
            wp_die('Error uploading file.');
        }
    }

    // Process the uploaded Excel file
    private function process_excel_file($file_path)
    {
        // Create a new Reader object
        $reader = new Xlsx();

        // Load the Excel file
        $spreadsheet = $reader->load($file_path);

        // Get the first worksheet
        $worksheet = $spreadsheet->getActiveSheet();

        // Start building HTML table
        $table_html = '<table border="1">';

        // Loop through rows and cells
        foreach ($worksheet->getRowIterator() as $row) {
            $table_html .= '<tr>';
            $cellIterator = $row->getCellIterator();
            $cellIterator->setIterateOnlyExistingCells(false);
            foreach ($cellIterator as $cell) {
                $table_html .= '<td>' . esc_html($cell->getValue()) . '</td>';
            }
            $table_html .= '</tr>';
        }

        $table_html .= '</table>';

        return $table_html;
    }


    public function display_uploaded_excel_table()
    {
        // Retrieve table HTML from option
        $table_html = get_option('excel_table_display_data');

        // Return the table HTML
        return $table_html;
    }
}

// Instantiate the plugin class
new Excel_Table_Display();
